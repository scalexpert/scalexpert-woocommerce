[fix 1.0.2] - 2024-03-12
Version 1.0.2 of plugin woocommerce
Content : e-financing solutions split payment & long term credit.

### Fixed

- Add tests for showlogo_cart in views/payment-buttons
- Add tests for Product attributes during Checkout
- Add debug explanation in Readme Template Section

[fix 1.0.1] - 2024-02-26
Version 1.0.1 of plugin woocommerce
Content : e-financing solutions split payment & long term credit.

### Fixed

- Fix url api

[1.0.0] - 2024-02-12 
Version 1.0.0 of plugin woocommerce 
Content : e-financing solutions split payment & long term credit.

