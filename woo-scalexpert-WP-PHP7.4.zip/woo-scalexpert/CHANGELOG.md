[fix 1.0.1] - 2024-02-26
Version 1.0.1 of plugin woocommerce
Content : e-financing solutions split payment & long term credit.

### Fixed

- Fix url api