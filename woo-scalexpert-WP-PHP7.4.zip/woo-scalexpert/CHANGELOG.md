[1.0.0] - 2024-02-12
Version 1.0.0 of plugin woocommerce 
Content : e-financing solutions split payment & long term credit.