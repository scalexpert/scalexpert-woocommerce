<h1 align="center">woo-scalexpert</h1>
<p align="center">Plugin scalexpert for woocommerce payment</p>
<h3>Build</h3>

For build sass and js, go to dir : `woo-scalexpert/_dev`

install and use node 18.x
and run command : 
```bash
npm i
npm run build       // build assets front for porduction
npm run build:dev   // build assets front for development
npm run watch       // watch build assets front for development
```
